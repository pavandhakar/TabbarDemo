//
//  ViewController.swift
//  tabbarDemo
//
//  Created by ireslab-02 on 19/08/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnShowAction(_ sender:UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "tabbarVC") as! tabbarVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

}

